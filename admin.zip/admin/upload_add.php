<?
// recup du reste du formulaire 
include("../connex.php");
$addmod = $_GET['addmod'];
$id=$_GET["id"];


$titre = trim(utf8_encode($_POST['titre']));
$texte = trim(utf8_encode($_POST['texte']));
$datein = $_POST['datepicker'];

$nomdefichier=$_FILES['imagenews']['tmp_name'];
$tailledefichier=$_FILES['imagenews']['size']; 
$extfichier= strtolower(  substr(  strrchr($_FILES['imagenews']['name'], '.')  ,1)  );
//echo $extfichier."<- ext?    " ;


echo $titre.'<br>'.$texte.'<br><br>En date du '.$datein ;
echo '<br><br>';

// ajout dans la db
if($addmod!="mod") $resultat = "INSERT INTO news SET titre='$titre', texte='$texte', datein='$datein' ";
else 
{
$texte = addcslashes($texte,'\'');
$resultat = "UPDATE news SET titre='$titre', texte='$texte', datein='$datein' WHERE id='$id' ";
echo "<script type='text/javascript'>document.location.replace('gestion_news.php');</script>";
}
if ($mysqli->query($resultat) === TRUE) {
    //echo "New record created successfully";
} else {
    echo "Error: " . $resultat . "<br>" . $mysqli->error;
}
$futuridphoto=$mysqli->insert_id;
$futuridphotoext=$futuridphoto.".".$extfichier;
$resultat = "UPDATE news SET img='$futuridphotoext' where id='$futuridphoto'";
if ($mysqli->query($resultat) === TRUE) {
   // echo "update successfully";
} else {
    echo "Error: " . $resultat . "<br>" . $mysqli->error;
}
//printf("Le dernier ID inséré dans est le id %d.\n", $futuridphoto);


recup_photo($futuridphoto,$nomdefichier,$tailledefichier,$extfichier);





?>

<br>


<?
function recup_photo($futuridphoto,$nomdefichier,$tailledefichier,$extfichier)
{
$uploaddir = '../img_serveur/';
$fichier_tmp=$nomdefichier;
//echo $fichier_tmp."   ";
$uploadfile = $uploaddir.$futuridphoto.".".$extfichier;
//echo $uploadfile;
$resultat = move_uploaded_file($fichier_tmp,$uploadfile);
//if($resultat) echo "    ok";
//else echo "    pas ok";


}



?>